import plotly 
plotly.tools.set_credentials_file(username='vagisha', api_key='Qcl3DGmQ8oWR81iAHOlV')